﻿namespace My_First_Program
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.typeGroupBox = new System.Windows.Forms.GroupBox();
            this.seniorRadioButton = new System.Windows.Forms.RadioButton();
            this.studentRadioButton = new System.Windows.Forms.RadioButton();
            this.childRadioButton = new System.Windows.Forms.RadioButton();
            this.adultRadioButton = new System.Windows.Forms.RadioButton();
            this.optionsGroup = new System.Windows.Forms.GroupBox();
            this.trainerCheckBox = new System.Windows.Forms.CheckBox();
            this.karateCheckBox = new System.Windows.Forms.CheckBox();
            this.yogaCheckBox = new System.Windows.Forms.CheckBox();
            this.lengthGroup = new System.Windows.Forms.GroupBox();
            this.monthsTextBox = new System.Windows.Forms.TextBox();
            this.lengthPromptLabel = new System.Windows.Forms.Label();
            this.feesGroup = new System.Windows.Forms.GroupBox();
            this.totalFeeDisplay = new System.Windows.Forms.Label();
            this.totalLabel = new System.Windows.Forms.Label();
            this.monthlyFeeDisplay = new System.Windows.Forms.Label();
            this.monthlyLabel = new System.Windows.Forms.Label();
            this.calcButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.typeGroupBox.SuspendLayout();
            this.optionsGroup.SuspendLayout();
            this.lengthGroup.SuspendLayout();
            this.feesGroup.SuspendLayout();
            this.SuspendLayout();
            // 
            // typeGroupBox
            // 
            this.typeGroupBox.Controls.Add(this.seniorRadioButton);
            this.typeGroupBox.Controls.Add(this.studentRadioButton);
            this.typeGroupBox.Controls.Add(this.childRadioButton);
            this.typeGroupBox.Controls.Add(this.adultRadioButton);
            this.typeGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeGroupBox.Location = new System.Drawing.Point(42, 49);
            this.typeGroupBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.typeGroupBox.Name = "typeGroupBox";
            this.typeGroupBox.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.typeGroupBox.Size = new System.Drawing.Size(225, 231);
            this.typeGroupBox.TabIndex = 0;
            this.typeGroupBox.TabStop = false;
            this.typeGroupBox.Text = "Type of Membership";
            // 
            // seniorRadioButton
            // 
            this.seniorRadioButton.AutoSize = true;
            this.seniorRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.seniorRadioButton.Location = new System.Drawing.Point(16, 151);
            this.seniorRadioButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.seniorRadioButton.Name = "seniorRadioButton";
            this.seniorRadioButton.Size = new System.Drawing.Size(139, 24);
            this.seniorRadioButton.TabIndex = 3;
            this.seniorRadioButton.TabStop = true;
            this.seniorRadioButton.Text = "S&enior Citizen";
            this.seniorRadioButton.UseVisualStyleBackColor = true;
            // 
            // studentRadioButton
            // 
            this.studentRadioButton.AutoSize = true;
            this.studentRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.studentRadioButton.Location = new System.Drawing.Point(16, 115);
            this.studentRadioButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.studentRadioButton.Name = "studentRadioButton";
            this.studentRadioButton.Size = new System.Drawing.Size(91, 24);
            this.studentRadioButton.TabIndex = 2;
            this.studentRadioButton.TabStop = true;
            this.studentRadioButton.Text = "&Student";
            this.studentRadioButton.UseVisualStyleBackColor = true;
            // 
            // childRadioButton
            // 
            this.childRadioButton.AutoSize = true;
            this.childRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.childRadioButton.Location = new System.Drawing.Point(16, 80);
            this.childRadioButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.childRadioButton.Name = "childRadioButton";
            this.childRadioButton.Size = new System.Drawing.Size(170, 24);
            this.childRadioButton.TabIndex = 1;
            this.childRadioButton.TabStop = true;
            this.childRadioButton.Text = "Chil&d (12 && under)";
            this.childRadioButton.UseVisualStyleBackColor = true;
            // 
            // adultRadioButton
            // 
            this.adultRadioButton.AutoSize = true;
            this.adultRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.adultRadioButton.Location = new System.Drawing.Point(16, 45);
            this.adultRadioButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.adultRadioButton.Name = "adultRadioButton";
            this.adultRadioButton.Size = new System.Drawing.Size(144, 24);
            this.adultRadioButton.TabIndex = 0;
            this.adultRadioButton.TabStop = true;
            this.adultRadioButton.Text = "Standard &Adult";
            this.adultRadioButton.UseVisualStyleBackColor = true;
            // 
            // optionsGroup
            // 
            this.optionsGroup.Controls.Add(this.trainerCheckBox);
            this.optionsGroup.Controls.Add(this.karateCheckBox);
            this.optionsGroup.Controls.Add(this.yogaCheckBox);
            this.optionsGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.optionsGroup.Location = new System.Drawing.Point(357, 49);
            this.optionsGroup.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.optionsGroup.Name = "optionsGroup";
            this.optionsGroup.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.optionsGroup.Size = new System.Drawing.Size(333, 231);
            this.optionsGroup.TabIndex = 1;
            this.optionsGroup.TabStop = false;
            this.optionsGroup.Text = "Options";
            // 
            // trainerCheckBox
            // 
            this.trainerCheckBox.AutoSize = true;
            this.trainerCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trainerCheckBox.Location = new System.Drawing.Point(56, 152);
            this.trainerCheckBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.trainerCheckBox.Name = "trainerCheckBox";
            this.trainerCheckBox.Size = new System.Drawing.Size(159, 24);
            this.trainerCheckBox.TabIndex = 2;
            this.trainerCheckBox.Text = "&Personal Trainer";
            this.trainerCheckBox.UseVisualStyleBackColor = true;
            // 
            // karateCheckBox
            // 
            this.karateCheckBox.AutoSize = true;
            this.karateCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.karateCheckBox.Location = new System.Drawing.Point(56, 97);
            this.karateCheckBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.karateCheckBox.Name = "karateCheckBox";
            this.karateCheckBox.Size = new System.Drawing.Size(84, 24);
            this.karateCheckBox.TabIndex = 1;
            this.karateCheckBox.Text = "&Karate";
            this.karateCheckBox.UseVisualStyleBackColor = true;
            // 
            // yogaCheckBox
            // 
            this.yogaCheckBox.AutoSize = true;
            this.yogaCheckBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.yogaCheckBox.Location = new System.Drawing.Point(56, 45);
            this.yogaCheckBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.yogaCheckBox.Name = "yogaCheckBox";
            this.yogaCheckBox.Size = new System.Drawing.Size(72, 24);
            this.yogaCheckBox.TabIndex = 0;
            this.yogaCheckBox.Text = "&Yoga";
            this.yogaCheckBox.UseVisualStyleBackColor = true;
            // 
            // lengthGroup
            // 
            this.lengthGroup.Controls.Add(this.monthsTextBox);
            this.lengthGroup.Controls.Add(this.lengthPromptLabel);
            this.lengthGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lengthGroup.Location = new System.Drawing.Point(42, 292);
            this.lengthGroup.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lengthGroup.Name = "lengthGroup";
            this.lengthGroup.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.lengthGroup.Size = new System.Drawing.Size(225, 222);
            this.lengthGroup.TabIndex = 2;
            this.lengthGroup.TabStop = false;
            this.lengthGroup.Text = "Membership Length";
            // 
            // monthsTextBox
            // 
            this.monthsTextBox.Location = new System.Drawing.Point(27, 117);
            this.monthsTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.monthsTextBox.Name = "monthsTextBox";
            this.monthsTextBox.Size = new System.Drawing.Size(168, 26);
            this.monthsTextBox.TabIndex = 1;
            // 
            // lengthPromptLabel
            // 
            this.lengthPromptLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lengthPromptLabel.Location = new System.Drawing.Point(12, 45);
            this.lengthPromptLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lengthPromptLabel.Name = "lengthPromptLabel";
            this.lengthPromptLabel.Size = new System.Drawing.Size(184, 68);
            this.lengthPromptLabel.TabIndex = 0;
            this.lengthPromptLabel.Text = "Enter the Number of Months:";
            // 
            // feesGroup
            // 
            this.feesGroup.Controls.Add(this.totalFeeDisplay);
            this.feesGroup.Controls.Add(this.totalLabel);
            this.feesGroup.Controls.Add(this.monthlyFeeDisplay);
            this.feesGroup.Controls.Add(this.monthlyLabel);
            this.feesGroup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.feesGroup.Location = new System.Drawing.Point(357, 292);
            this.feesGroup.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.feesGroup.Name = "feesGroup";
            this.feesGroup.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.feesGroup.Size = new System.Drawing.Size(333, 222);
            this.feesGroup.TabIndex = 3;
            this.feesGroup.TabStop = false;
            this.feesGroup.Text = "Membership Fees";
            // 
            // totalFeeDisplay
            // 
            this.totalFeeDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalFeeDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalFeeDisplay.Location = new System.Drawing.Point(174, 118);
            this.totalFeeDisplay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalFeeDisplay.Name = "totalFeeDisplay";
            this.totalFeeDisplay.Size = new System.Drawing.Size(111, 38);
            this.totalFeeDisplay.TabIndex = 3;
            this.totalFeeDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalLabel
            // 
            this.totalLabel.AutoSize = true;
            this.totalLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.totalLabel.Location = new System.Drawing.Point(80, 131);
            this.totalLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.totalLabel.Name = "totalLabel";
            this.totalLabel.Size = new System.Drawing.Size(51, 20);
            this.totalLabel.TabIndex = 2;
            this.totalLabel.Text = "Total:";
            // 
            // monthlyFeeDisplay
            // 
            this.monthlyFeeDisplay.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.monthlyFeeDisplay.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monthlyFeeDisplay.Location = new System.Drawing.Point(174, 35);
            this.monthlyFeeDisplay.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.monthlyFeeDisplay.Name = "monthlyFeeDisplay";
            this.monthlyFeeDisplay.Size = new System.Drawing.Size(111, 38);
            this.monthlyFeeDisplay.TabIndex = 1;
            this.monthlyFeeDisplay.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // monthlyLabel
            // 
            this.monthlyLabel.AutoSize = true;
            this.monthlyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monthlyLabel.Location = new System.Drawing.Point(34, 45);
            this.monthlyLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.monthlyLabel.Name = "monthlyLabel";
            this.monthlyLabel.Size = new System.Drawing.Size(105, 20);
            this.monthlyLabel.TabIndex = 0;
            this.monthlyLabel.Text = "Monthly Fee:";
            // 
            // calcButton
            // 
            this.calcButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.calcButton.Location = new System.Drawing.Point(58, 582);
            this.calcButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.calcButton.Name = "calcButton";
            this.calcButton.Size = new System.Drawing.Size(112, 85);
            this.calcButton.TabIndex = 4;
            this.calcButton.Text = "&Calculate";
            this.calcButton.UseVisualStyleBackColor = true;
            this.calcButton.Click += new System.EventHandler(this.calcButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.clearButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.clearButton.Location = new System.Drawing.Point(306, 582);
            this.clearButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(112, 85);
            this.clearButton.TabIndex = 5;
            this.clearButton.Text = "Clea&r";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exitButton.Location = new System.Drawing.Point(554, 582);
            this.exitButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(112, 85);
            this.exitButton.TabIndex = 6;
            this.exitButton.Text = "E&xit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AcceptButton = this.calcButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.clearButton;
            this.ClientSize = new System.Drawing.Size(726, 709);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calcButton);
            this.Controls.Add(this.feesGroup);
            this.Controls.Add(this.lengthGroup);
            this.Controls.Add(this.optionsGroup);
            this.Controls.Add(this.typeGroupBox);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Fitness Membership Calculator";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.typeGroupBox.ResumeLayout(false);
            this.typeGroupBox.PerformLayout();
            this.optionsGroup.ResumeLayout(false);
            this.optionsGroup.PerformLayout();
            this.lengthGroup.ResumeLayout(false);
            this.lengthGroup.PerformLayout();
            this.feesGroup.ResumeLayout(false);
            this.feesGroup.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox typeGroupBox;
        private System.Windows.Forms.RadioButton seniorRadioButton;
        private System.Windows.Forms.RadioButton studentRadioButton;
        private System.Windows.Forms.RadioButton childRadioButton;
        private System.Windows.Forms.RadioButton adultRadioButton;
        private System.Windows.Forms.GroupBox optionsGroup;
        private System.Windows.Forms.CheckBox trainerCheckBox;
        private System.Windows.Forms.CheckBox karateCheckBox;
        private System.Windows.Forms.CheckBox yogaCheckBox;
        private System.Windows.Forms.GroupBox lengthGroup;
        private System.Windows.Forms.TextBox monthsTextBox;
        private System.Windows.Forms.Label lengthPromptLabel;
        private System.Windows.Forms.GroupBox feesGroup;
        private System.Windows.Forms.Label totalFeeDisplay;
        private System.Windows.Forms.Label totalLabel;
        private System.Windows.Forms.Label monthlyFeeDisplay;
        private System.Windows.Forms.Label monthlyLabel;
        private System.Windows.Forms.Button calcButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

