﻿using System;
using System.Windows.Forms;

namespace My_First_Program
{
    /// <summary>
    /// Main form for the Membership Fee Calculator application.
    /// Allows users to select a membership type and additional options
    /// to calculate monthly and total fees.
    /// </summary>
    public partial class Form1 : Form
    {
        /// <summary>
        /// Initializes the form components.
        /// </summary>
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Handles the button click event to calculate the membership fees.
        /// </summary>
        /// <param name="sender">The button control.</param>
        /// <param name="e">Event data.</param>
        private void calcButton_Click(object sender, EventArgs e)
        {
            // Validate months input (must be between 1 and 12)
            if (!int.TryParse(monthsTextBox.Text, out int months) || months < 1 || months > 12)
            {
                monthsTextBox.Text = "";
                MessageBox.Show("Invalid entry of membership length. \nPlease enter a value between 1 and 12.");
                return; // Stop execution if input is invalid
            }

            // Get selected membership type
            Membership membership = GetMembershipType();
            double baseFee = membership.GetBaseMembershipFee();
            double additionalFee = GetAdditionalOptionsFee();

            // Calculate monthly and total fees
            double monthlyFee = baseFee + additionalFee;
            double totalFee = monthlyFee * months;

            // Display results
            monthlyFeeDisplay.Text = monthlyFee.ToString("c");
            totalFeeDisplay.Text = totalFee.ToString("c");
        }

        /// <summary>
        /// Retrieves the selected membership type based on user input.
        /// </summary>
        /// <returns>A <see cref="Membership"/> object representing the selected type.</returns>
        private Membership GetMembershipType()
        {
            if (seniorRadioButton.Checked) return new SeniorMembership();
            if (childRadioButton.Checked) return new ChildMembership();
            if (studentRadioButton.Checked) return new StudentMembership();
            return new AdultMembership(); // Default to Adult Membership
        }

        /// <summary>
        /// Calculates the additional fee based on selected options.
        /// </summary>
        /// <returns>The total additional fee.</returns>
        private double GetAdditionalOptionsFee()
        {
            double additionalFee = 0;

            if (yogaCheckBox.Checked) additionalFee += (new Yoga().GetFee());
            if (karateCheckBox.Checked) additionalFee += (new Karate().GetFee());
            if (trainerCheckBox.Checked) additionalFee += (new Trainer().GetFee());

            return additionalFee;
        }

        /// <summary>
        /// Handles the button click event to clear all inputs and reset the form.
        /// </summary>
        /// <param name="sender">The button control.</param>
        /// <param name="e">Event data.</param>
        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clears all options, resets selections to default
            yogaCheckBox.Checked = false;
            karateCheckBox.Checked = false;
            trainerCheckBox.Checked = false;
            monthsTextBox.Text = "";
            monthlyFeeDisplay.Text = "";
            totalFeeDisplay.Text = "";
            adultRadioButton.Checked = true;
        }

        /// <summary>
        /// Handles the button click event to exit the application.
        /// </summary>
        /// <param name="sender">The button control.</param>
        /// <param name="e">Event data.</param>
        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Handles form load event.
        /// </summary>
        /// <param name="sender">The form control.</param>
        /// <param name="e">Event data.</param>
        private void Form1_Load(object sender, EventArgs e)
        {
            // Currently empty but can be used for future initialization.
        }
    }
}
